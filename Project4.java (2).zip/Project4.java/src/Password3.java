import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

public class Password3 {

    static final String ZIP_NAME = "protected3.zip"; // zip file name
    static final String EXTRACT_PATH = "extracted_contents"; // if password is correct then extract there
    static volatile boolean found = false; // true if password is found and stop other thread 
    static long starttime;//to store time when starting
    /**
     *main method to start password cracking process using 2 threads 
     *first thread a to m and second thread n to z
     */
    public static void main(String[] args) {
        starttime = System.currentTimeMillis();//start time before staring thread

        // frist thread try all password from a to m
        Thread t1 = new Thread(() -> guessPassword("", 'a', 'm'));

        //second thread try all password from n to z
        Thread t2 = new Thread(() -> guessPassword("", 'n', 'z'));

        t1.start();//start first thread
        t2.start();//start second thread
    }
    /**
     * recursive method to build and try all 3 letter lowercase password
     * @param pass current password being made
     * @param start first letter this thread try 
     * @param end last letter this thread try
     */
    static void guessPassword(String pass, char start, char end) {//the recusrssion logic cretaed with chatgpt
        if (found) return; // when password found then stop

        if (pass.length() == 3) { // if password has 3 letter, then try
            trypassword(pass);
            return;
        }
        //loop from start to end and keep adding next letter
        for (char ch = start; ch <= end && !found; ch++) {
            guessPassword(pass + ch, 'a', 'z');//next letter from a to z
        }
    }
    /**
     * tries to unzip fileif success then print password and stop program
     * @param pass password to test
     */
    static void trypassword(String pass) {
        try {
            ZipFile zip = new ZipFile(ZIP_NAME); // open zip
            zip.setPassword(pass); // set password to try
            zip.extractAll(EXTRACT_PATH); // try to unzip
            //if unzip works then password is correct
            if (!found) {
                found = true;//set found password to true sothat other thread stop
                long endtime = System.currentTimeMillis();//end time
                long duration= endtime-starttime;//total time taken
                System.out.println("Password Found:"+pass);//show correct password
                System.out.println("Total time to find password is "+duration+"ms");//shoe total time
                System.exit(0); // exit program
            }

        } catch (Exception e) {
            //incorrect password and continue
        }}
    }
